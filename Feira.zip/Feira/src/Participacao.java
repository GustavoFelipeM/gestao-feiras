public class Participacao {
    private Produtor produtor;
    private EdicaoFeira edicaoFeira;
    private int banca;

    public void inscreverEmEdicaoFutura(){

    }
    public void alocarBanca(){

    }
    public void cancelarParticipacao(){

    }
    public boolean verificarProdutorAtivo(){
        return false;
    }
    public boolean verificarPendencias(){
        return false;
    }
}
