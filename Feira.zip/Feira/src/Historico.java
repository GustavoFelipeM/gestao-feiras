import java.util.ArrayList;
import java.util.List;

public class Historico {
    public List<Venda> vendaPorProdutor(){
        List<Venda> vendaProdutor = new ArrayList<>();
        return vendaProdutor;
    }
    public List<Venda> vendaPorProduto(){
        List<Venda> vendaProduto = new ArrayList<>();
        return vendaProduto;
    }
    public List<Venda> vendaPorEdicao(){
        List<Venda> vendaEdicao = new ArrayList<>();
        return vendaEdicao;
    }


}
