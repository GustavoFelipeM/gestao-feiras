public class Relatorio {
    public void gerarPorEdicao(){

    }
    public void gerarPorProdutor(){

    }
    public void gerarPorProduto(){

    }
    public Relatorio participacaoPorProdutor(){
        return new Relatorio();
    }
    public int frequenciaProdutor(){
        return 0;
    }
    public double mediaVendasPorProdutor(){
        return 0;
    }
}
