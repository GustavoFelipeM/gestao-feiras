public class Exportar {
    public void exportarPdf(){

    }
    public void exportarCsv(){

    }
    public void agruparPorCategoria(){

    }
    public void agruparPorProduto(){

    }
}
